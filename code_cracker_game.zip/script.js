let attempts = 0;
const secretCode = generateCode();

document.getElementById('guessButton').addEventListener('click', handleGuess);
document.getElementById('guessInput').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    handleGuess();
  }
});

function generateCode() {
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += Math.floor(Math.random() * 10).toString();
  }
  console.log('Secret code (for testing):', code); // Remove or comment out in production
  return code;
}

function handleGuess() {
  const guess = document.getElementById('guessInput').value.trim();
  if (!/^\d{4}$/.test(guess)) {
    alert('Please enter exactly 4 digits.');
    return;
  }

  attempts++;
  const feedback = getFeedback(guess, secretCode);
  document.getElementById('result').innerHTML = `
    <p>Attempt ${attempts}: ${guess}</p>
    <p>Correct digits in correct position: ${feedback.correctPosition}</p>
    <p>Correct digits in wrong position: ${feedback.correctDigit}</p>
  `;

  if (feedback.correctPosition === 4) {
    alert(\`Congratulations! You cracked the code in \${attempts} attempts!\`);
    resetGame();
  }
}

function getFeedback(guess, code) {
  let correctPosition = 0;
  let correctDigit = 0;

  const codeArr = code.split('');
  const guessArr = guess.split('');

  const codeUsed = Array(4).fill(false);
  const guessUsed = Array(4).fill(false);

  // First pass: correct positions
  for (let i = 0; i < 4; i++) {
    if (guessArr[i] === codeArr[i]) {
      correctPosition++;
      codeUsed[i] = true;
      guessUsed[i] = true;
    }
  }

  // Second pass: correct digits wrong position
  for (let i = 0; i < 4; i++) {
    if (guessUsed[i]) continue;
    for (let j = 0; j < 4; j++) {
      if (codeUsed[j]) continue;
      if (guessArr[i] === codeArr[j]) {
        correctDigit++;
        codeUsed[j] = true;
        break;
      }
    }
  }

  return { correctPosition, correctDigit };
}

function resetGame() {
  // Generate a new code and reset attempts
  location.reload();
}